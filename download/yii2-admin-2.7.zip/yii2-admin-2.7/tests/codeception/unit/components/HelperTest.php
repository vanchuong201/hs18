<?php

namespace tests\codeception\unit\components;

/**
 * Description of HelperTest
 *
 * @author Misbahul D Munir <misbahuldmunir@gmail.com>
 * @since 1.0
 */
class HelperTest extends \tests\codeception\unit\TestCase
{
    public function testFilter()
    {
        $this->assertTrue(true);
    }
}
