<?php

namespace tests\codeception\unit\models;

use tests\codeception\unit\TestCase;

/**
 * Description of RouteTest
 *
 * @author Misbahul D Munir <misbahuldmunir@gmail.com>
 * @since 2.5
 */
class RouteTest extends TestCase
{
    public function testGetRouteList()
    {
        $this->assertTrue(true);
    }
}
