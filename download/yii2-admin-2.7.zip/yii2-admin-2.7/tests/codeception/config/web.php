<?php
return[
    'components' => [
        'request' => [
            'cookieValidationKey' => 'testme',
        ],
    ]
];
